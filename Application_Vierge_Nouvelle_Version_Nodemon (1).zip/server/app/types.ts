export default {
  Server: Symbol("Server"),
  Application: Symbol("Application"),
  DatabaseController: Symbol("DatabaseController"),
  DatabaseService: Symbol("DatabaseService"),
};
