export interface IEnvironment {
    production: boolean;
}
